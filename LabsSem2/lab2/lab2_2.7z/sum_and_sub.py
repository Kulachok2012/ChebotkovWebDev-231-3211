def sum_and_sub(a, b):
    print(a + b, a - b)


if __name__ == '__main__':
    a,b = int(input()), int(input())
    sum_and_sub(a, b)

