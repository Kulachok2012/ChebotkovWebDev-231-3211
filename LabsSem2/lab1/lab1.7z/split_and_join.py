n = input().split()
print('-'.join(n))