a, b = int(input()), int(input())
print(a + b, a - b, a * b, sep="\n")
