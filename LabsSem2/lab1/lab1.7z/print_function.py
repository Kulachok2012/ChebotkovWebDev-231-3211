n = int(input())

print(*range(1, n + 1), sep="")
