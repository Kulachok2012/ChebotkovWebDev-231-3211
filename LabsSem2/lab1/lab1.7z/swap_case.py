print(input().swapcase())
